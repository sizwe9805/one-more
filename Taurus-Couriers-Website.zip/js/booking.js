
document.getElementById('bookingForm').addEventListener('change', function() {
  const weight = parseFloat(document.querySelector('input[name="weight"]').value) || 0;
  const type = document.querySelector('select[name="deliveryType"]').value;
  let base = 0;

  switch (type) {
    case 'standard_local': base = 105; break;
    case 'standard_national': base = weight > 2 ? 130 : 90; break;
    case 'express_same_day': base = 555; break;
    case 'express_overnight': base = 105; break;
    case 'economy': base = 90; break;
  }

  let extra = weight > 25 ? (weight - 25) * 75 : 0;
  let subtotal = base + extra + 5.5;
  let fuel = subtotal * 0.3482;
  let total = subtotal + fuel;
  total += total * 0.15;

  document.getElementById('priceDisplay').innerText = 'Estimated Price: R' + total.toFixed(2);
});
